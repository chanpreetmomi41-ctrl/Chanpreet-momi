const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const session = require("express-session");
const SQLiteStoreFactory = require("connect-sqlite3");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const nodemailer = require("nodemailer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";
const dataDir = process.env.DATA_DIR || path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("Set SESSION_SECRET to a long random value (at least 32 characters).");
}
if (!process.env.ADMIN_PASSWORD_HASH) {
  throw new Error("Set ADMIN_PASSWORD_HASH to a bcrypt hash of a strong admin password.");
}
if (isProduction && process.env.TRUST_PROXY !== "true") {
  console.warn("If deployed behind a trusted HTTPS reverse proxy, configure TRUST_PROXY=true.");
}

app.disable("x-powered-by");
if (isProduction && process.env.TRUST_PROXY === "true") app.set("trust proxy", 1);
app.use(helmet());
// Razorpay webhooks must be verified against the exact raw request body.
app.post("/api/donations/webhook", express.raw({ type: "application/json", limit: "100kb" }), (req, res) => {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  const signature = req.get("x-razorpay-signature");
  if (!secret || !signature || !Buffer.isBuffer(req.body)) return res.status(400).send("Webhook not configured");
  const expected = crypto.createHmac("sha256", secret).update(req.body).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(signature, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(400).send("Invalid signature");
  let event;
  try { event = JSON.parse(req.body.toString("utf8")); } catch { return res.status(400).send("Invalid JSON"); }
  if (event.event === "payment.captured" || event.event === "order.paid") {
    const payment = event.payload?.payment?.entity;
    const order = event.payload?.order?.entity;
    const orderId = payment?.order_id || order?.id;
    const paymentId = payment?.id || null;
    if (orderId) db.prepare("UPDATE donations SET status='paid', payment_id=COALESCE(?, payment_id) WHERE order_id=?").run(paymentId, orderId);
  } else if (event.event === "payment.failed") {
    const payment = event.payload?.payment?.entity;
    if (payment?.order_id) db.prepare("UPDATE donations SET status='failed', payment_id=COALESCE(?, payment_id) WHERE order_id=? AND status!='paid'").run(payment.id || null, payment.order_id);
  }
  res.json({ received: true });
});
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "10kb" }));

const db = new Database(path.join(dataDir, "begampura.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS donations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT NOT NULL UNIQUE,
    amount_paise INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'created',
    payment_id TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    district TEXT NOT NULL,
    family_size TEXT NOT NULL,
    housing TEXT NOT NULL,
    details TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);
const getSettingStmt = db.prepare("SELECT value FROM settings WHERE key = ?");
const setSettingStmt = db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
function getSetting(key, fallback) {
  const row = getSettingStmt.get(key);
  return row ? row.value : fallback;
}
function setSetting(key, value) { setSettingStmt.run(key, value); }

if (!getSetting("gateway_status", null)) setSetting("gateway_status", "pending");
if (!getSetting("methods", null)) setSetting("methods", JSON.stringify({ upi: true, cards: true, other: true }));

const SQLiteStore = SQLiteStoreFactory(session);
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir, concurrentDB: true }),
  name: "begampura.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: "strict",
    maxAge: 30 * 60 * 1000
  }
}));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 5,
  standardHeaders: "draft-7", legacyHeaders: false,
  message: { error: "Too many login attempts. Try again later." }
});
const contactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 5,
  standardHeaders: "draft-7", legacyHeaders: false,
  message: { error: "Too many messages. Try again later." }
});
const adminLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false });
const applicationLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 3, standardHeaders: "draft-7", legacyHeaders: false });

function requireAdmin(req, res, next) {
  if (req.session && req.session.admin === true) return next();
  return res.status(401).json({ error: "Admin login required." });
}
function cleanText(value, maxLength) {
  if (typeof value !== "string") return "";
  return value.trim().replace(/[<>]/g, "").slice(0, maxLength);
}
function csrfCheck(req, res, next) {
  // SameSite=Strict is defense-in-depth; require matching same-origin Origin on mutating admin requests.
  const origin = req.get("origin");
  const expected = `${req.protocol}://${req.get("host")}`;
  if (!origin || origin !== expected) return res.status(403).json({ error: "Request origin check failed." });
  next();
}

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/admin/session", (req, res) => {
  res.json({ authenticated: req.session?.admin === true });
});
app.post("/api/admin/login", loginLimiter, async (req, res) => {
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  if (!password || password.length > 200) return res.status(400).json({ error: "Enter your admin password." });
  try {
    const valid = await bcrypt.compare(password, process.env.ADMIN_PASSWORD_HASH);
    if (!valid) return res.status(401).json({ error: "Invalid login." });
    req.session.regenerate((err) => {
      if (err) return res.status(500).json({ error: "Could not start secure session." });
      req.session.admin = true;
      req.session.save((saveErr) => {
        if (saveErr) return res.status(500).json({ error: "Could not save session." });
        res.json({ ok: true });
      });
    });
  } catch {
    res.status(500).json({ error: "Login service error." });
  }
});
app.post("/api/admin/logout", adminLimiter, csrfCheck, requireAdmin, (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("begampura.sid", { httpOnly: true, secure: isProduction, sameSite: "strict" });
    res.json({ ok: true });
  });
});

app.get("/api/admin/settings", adminLimiter, requireAdmin, (_req, res) => {
  let methods;
  try { methods = JSON.parse(getSetting("methods", "{}")); } catch { methods = { upi: true, cards: true, other: true }; }
  res.json({
    gatewayStatus: "pending",
    methods,
    message: "Razorpay checkout is not integrated/enabled yet. Settings here are preferences only."
  });
});

app.post("/api/admin/settings", adminLimiter, csrfCheck, requireAdmin, (req, res) => {
  const input = req.body?.methods || {};
  const methods = {
    upi: input.upi === true,
    cards: input.cards === true,
    other: input.other === true
  };
  // Do not allow enabling live payments from this settings screen. Provider approval,
  // server-side order creation, signature verification, and signed webhooks must be implemented first.
  setSetting("methods", JSON.stringify(methods));
  setSetting("gateway_status", "pending");
  res.json({
    ok: true,
    gatewayStatus: "pending",
    methods,
    message: "Preferences saved. Live payments remain disabled."
  });
});

app.post("/api/contact", contactLimiter, async (req, res) => {
  const name = cleanText(req.body?.name, 100);
  const email = cleanText(req.body?.email, 254);
  const message = cleanText(req.body?.message, 3000);
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || message.length < 5) {
    return res.status(400).json({ error: "Please provide a name, valid email, and message." });
  }
  const required = ["SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASS", "CONTACT_TO", "CONTACT_FROM"];
  if (required.some((key) => !process.env[key])) return res.status(503).json({ error: "Contact email is not configured yet." });
  try {
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT),
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
    await transporter.sendMail({
      from: process.env.CONTACT_FROM, to: process.env.CONTACT_TO, replyTo: email,
      subject: "Begampura website contact message",
      text: `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`
    });
    res.json({ ok: true });
  } catch (err) {
    console.error("Contact email delivery failed:", err.message);
    res.status(500).json({ error: "Message could not be sent. Please try again later." });
  }
});


app.post("/api/applications", applicationLimiter, (req, res) => {
  const name = cleanText(req.body?.name, 100);
  const phone = cleanText(req.body?.phone, 20);
  const district = cleanText(req.body?.district, 100);
  const familySize = cleanText(req.body?.familySize, 10);
  const housing = cleanText(req.body?.housing, 30);
  const details = cleanText(req.body?.details, 1500);
  const validFamilySizes = new Set(["1-2", "3-4", "5-6", "7+"]);
  const validHousing = new Set(["homeless", "temporary", "unsafe", "overcrowded", "other"]);
  if (!name || !phone || !district || !validFamilySizes.has(familySize) || !validHousing.has(housing) || req.body?.consent !== true) {
    return res.status(400).json({ error: "Please complete all required fields and consent." });
  }
  if (!/^[+()\d\s.-]{7,20}$/.test(phone)) return res.status(400).json({ error: "Please enter a valid phone number." });
  try {
    const result = db.prepare("INSERT INTO applications(name,phone,district,family_size,housing,details) VALUES(?,?,?,?,?,?)")
      .run(name, phone, district, familySize, housing, details);
    res.status(201).json({ ok: true, id: result.lastInsertRowid });
  } catch (err) {
    console.error("Application save failed:", err.message);
    res.status(500).json({ error: "Application could not be saved." });
  }
});

app.get("/api/admin/applications", adminLimiter, requireAdmin, (_req, res) => {
  const rows = db.prepare("SELECT id,name,phone,district,family_size AS familySize,housing,details,created_at AS createdAt FROM applications ORDER BY id DESC LIMIT 200").all();
  res.json({ applications: rows });
});

app.get("/api/donations/status", (_req, res) => {
  const enabled = process.env.DONATIONS_ENABLED === "true" && process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET;
  res.json({ enabled: Boolean(enabled), keyId: enabled ? process.env.RAZORPAY_KEY_ID : null,
    message: enabled ? "Payments are configured; complete test transactions before launch." : "Donations are disabled until the organization and provider are approved and credentials are configured." });
});

app.post("/api/donations/create", contactLimiter, async (req, res) => {
  const enabled = process.env.DONATIONS_ENABLED === "true" && process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET;
  if (!enabled) return res.status(503).json({ error: "Donations are currently disabled. Provider approval and configuration are required." });
  const amount = Number(req.body?.amount);
  // Fixed limits protect against malformed/unexpected values; amount is INR.
  if (!Number.isInteger(amount) || amount < 100 || amount > 100000) return res.status(400).json({ error: "Choose an amount between ₹100 and ₹1,00,000." });
  try {
    const auth = Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString("base64");
    const response = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST", headers: { "Authorization": `Basic ${auth}`, "Content-Type": "application/json" },
      body: JSON.stringify({ amount: amount * 100, currency: "INR", receipt: `bg-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`, notes: { project: "Begampura housing support" } })
    });
    const order = await response.json();
    if (!response.ok || !order.id) {
      console.error("Razorpay order creation failed", response.status);
      return res.status(502).json({ error: "Payment order could not be created." });
    }
    db.prepare("INSERT INTO donations(order_id,amount_paise,status) VALUES(?,?,'created')").run(order.id, amount * 100);
    res.status(201).json({ orderId: order.id, amount: order.amount, currency: order.currency, keyId: process.env.RAZORPAY_KEY_ID });
  } catch (err) {
    console.error("Donation order error:", err.message);
    res.status(502).json({ error: "Payment service is temporarily unavailable." });
  }
});

app.post("/api/donations/verify", contactLimiter, (req, res) => {
  const enabled = process.env.DONATIONS_ENABLED === "true" && process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET;
  if (!enabled) return res.status(503).json({ error: "Donations are currently disabled." });
  const orderId = typeof req.body?.razorpay_order_id === "string" ? req.body.razorpay_order_id : "";
  const paymentId = typeof req.body?.razorpay_payment_id === "string" ? req.body.razorpay_payment_id : "";
  const signature = typeof req.body?.razorpay_signature === "string" ? req.body.razorpay_signature : "";
  const row = db.prepare("SELECT order_id FROM donations WHERE order_id=?").get(orderId);
  if (!row || !paymentId || !signature) return res.status(400).json({ error: "Invalid payment details." });
  const expected = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET).update(`${orderId}|${paymentId}`).digest("hex");
  const a = Buffer.from(expected, "hex"), b = Buffer.from(signature, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(400).json({ error: "Payment verification failed." });
  db.prepare("UPDATE donations SET payment_id=?, status='signature_verified' WHERE order_id=? AND status!='paid'").run(paymentId, orderId);
  // A valid checkout signature is not the same as confirmed capture; webhook/Dashboard must confirm captured status.
  res.json({ ok: true, status: "verification_received", message: "Payment details verified. Final status is confirmed by provider webhook or dashboard." });
});
app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`Begampura server listening on port ${PORT}`));
