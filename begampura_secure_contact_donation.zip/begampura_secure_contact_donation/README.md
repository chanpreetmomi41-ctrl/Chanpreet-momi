# Begampura: secure contact + donation integration starter

This is a starter implementation, not a production-audited system. Donations are **disabled by default**.

## Features
- Existing Punjabi/English housing website and housing-interest application form.
- Contact form POSTs to `/api/contact`; requires SMTP settings and rate limits.
- Admin login and application viewing endpoints from the prior starter.
- Razorpay Standard Checkout scaffolding: server-side order creation, HMAC checkout signature verification, and signed webhook endpoint.
- `DONATIONS_ENABLED` defaults to `false`; live payments must not be enabled until the organization is eligible and the provider approves the account.

## Local setup
1. Use Node.js 20+.
2. Copy `.env.example` values into your hosting provider's secret environment settings. Do not commit secrets.
3. Install dependencies with `npm install`; run `npm start`.
4. Generate a strong random `SESSION_SECRET` (32+ chars) and a bcrypt hash for `ADMIN_PASSWORD_HASH`.
5. Configure a verified sender and SMTP/API email delivery before expecting the contact form to work.

## Razorpay setup (only after approval)
1. Apply for and obtain provider approval under the correct legal entity and bank account. Confirm what documents and purpose disclosures are required.
2. Test in Razorpay test mode first. Keep `DONATIONS_ENABLED=false` until provider eligibility, privacy/refund disclosures, database persistence, and testing are completed.
3. Set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and `RAZORPAY_WEBHOOK_SECRET` in hosting secrets. The secret must never be sent to browser code or committed.
4. Set webhook URL to `https://YOUR_DOMAIN/api/donations/webhook` and subscribe to `payment.captured`, `payment.failed`, and `order.paid` events as applicable. Use the webhook secret configured in the Razorpay dashboard.
5. After legal/provider approval and successful test verification, set `DONATIONS_ENABLED=true` and use live keys. Keep test and live keys separate.
6. Check captured payments in the provider dashboard. A browser success callback alone is not proof that funds have settled. Webhook events and dashboard reconciliation are needed.

## Important production work still required
- Replace SQLite/local filesystem storage with persistent storage/managed database and backups before accepting real applications or donations.
- Add privacy notice, retention/deletion process, refund policy, contact details, legal entity details, and receipts/ledger handling.
- Add CSRF protection appropriate to your deployment and audit the admin/application flows.
- Test Node/Express compatibility and Razorpay test payments in staging; this starter has not been independently security-audited.
- Contact form currently sends via SMTP; if using an email API instead, implement and test that provider separately.

## Compliance note
Because the NGO is currently unregistered, do not accept public donations until you have verified the legal structure, bank-account requirements, tax/receipt statements, and payment provider eligibility with a qualified Indian professional and the provider. Do not solicit foreign contributions without checking current FCRA requirements and obtaining applicable registration/prior permission.
